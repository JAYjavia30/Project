/***************************************************
 * CSCI 185 M01
 * Fall 2025
 *
 * Names: Jay Javia & Jesus Maldonado
 * Date: 12/10/2025
 */

import javax.swing.*;
import java.awt.*;
import java.lang.*;

public class GameGUI extends JFrame {
    private JFrame frame;
    private JTextArea logArea;
    private JLabel p1Label, p2Label, turnLabel, p1ImageLabel, p2ImageLabel;
    private JProgressBar p1HP, p2HP;
    private GameLogic p1, p2;
    private boolean vsAI;
    private String aiDifficulty;
    private boolean p1Turn = true;

    public GameGUI(boolean vsAI, String aiDifficulty, String p1Character, String p2Character) {
        this.vsAI = vsAI;
        this.aiDifficulty = aiDifficulty;
        p1 = createCharacter(p1Character);
        if (vsAI) {
            String aiChoice = getAIChoice();
            p2 = createCharacter(aiChoice);
            System.out.println("AI picked " + aiChoice);
        } else {
            p2 = createCharacter(p2Character);
        }
        setupGUI();
    }

    private GameLogic createCharacter(String name) {
        if (name == null) {
            name = "Invalid Choice";
        }
        return switch (name) {
            case "Knight" -> new GameLogic("Knight", 110, 10, 10);
            case "Zombie" -> new GameLogic("Zombie", 100, 14, 8);
            case "Mage" -> new GameLogic("Mage", 110, 12, 8);
            case "Skeleton" -> new GameLogic("Skeleton", 100, 14, 8);
            default -> new GameLogic(name, 0, 0, 0);
        };
    }

    private String getAIChoice() {
        int aiCharacterRoll = (int) (Math.random() * 4);
        return switch (aiCharacterRoll) {
            case 0 -> "Knight";
            case 1 -> "Zombie";
            case 2 -> "Mage";
            case 3 -> "Skeleton";
            default -> "Knight";
        };
    }
    
    private ImageIcon loadCharacterIcon(String name){
        String fileName;
        switch (name) {
            case "Knight" -> fileName = "/Knight.png";
            case "Zombie" -> fileName = "/Zombie.png";
            case "Mage" -> fileName = "/Mage.png";
            case "Skeleton" -> fileName = "/Skeleton.png";
            default -> fileName = "/Knight.png";
        }

        var url = getClass().getResource(fileName);

        if(url == null){
            System.err.println("Couldn't find image: " + fileName);
            return null;
        }
        Image img = new ImageIcon(url).getImage().getScaledInstance(120, 120, Image.SCALE_SMOOTH);
        return new ImageIcon(img);
    }

    private void setupGUI() {
        frame = new JFrame("Battle RPG");
        frame.setSize(600, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout(8,8));
        frame.getContentPane().setBackground(new Color(45, 45, 50));
        frame.setLocationRelativeTo(null);

        JPanel topPanel = new JPanel(new GridLayout(2, 3, 10, 5));
        topPanel.setBackground(new Color(60, 60, 40));
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        p1Label = new JLabel(p1.getName() + " HP:" + p1.getHealth());
        p1Label.setForeground(new Color(255, 0, 0));
        p1Label.setFont(new Font("Times New Roman", Font.BOLD, 12));

        p2Label = new JLabel(p2.getName() + " HP:" + p2.getHealth());
        p2Label.setForeground(new Color(255, 100, 34));
        p2Label.setFont(new Font("Arial", Font.BOLD, 12));

        p1HP = new JProgressBar(0, p1.getMaxHealth());
        p1HP.setValue(p1.getHealth());
        p1HP.setForeground(new Color(200, 135, 0));
        p1HP.setBackground(new Color(40, 40, 40));

        p2HP = new JProgressBar(0, p2.getMaxHealth());
        p2HP.setValue(p2.getHealth());
        p2HP.setForeground(new Color(70, 125, 23));
        p2HP.setBackground(new Color(40, 40, 40));

        turnLabel = new JLabel("Turn: " + (p1Turn ? p1.getName() : p2.getName()), SwingConstants.CENTER);
        turnLabel.setForeground(Color.YELLOW);
        turnLabel.setFont(new Font("Times New Roman", Font.BOLD, 12));

        topPanel.add(p1Label);
        topPanel.add(p2Label);
        topPanel.add(turnLabel);
        topPanel.add(p1HP);
        topPanel.add(p2HP);
        topPanel.add(new JLabel());

        frame.add(topPanel, BorderLayout.NORTH);

        logArea = new JTextArea();
        logArea.setEditable(false);
        logArea.setBackground(new Color(30, 30, 30));
        logArea.setForeground(new Color(200, 200, 200));
        logArea.setFont(new Font("Monospaced", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(logArea);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(80, 80, 80), 2));
        frame.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(30, 30, 30));
        buttonPanel.setBorder(BorderFactory.createLineBorder(new Color(10, 10, 10), 10));
        JButton attackButton = createButton("Attack", new Color(200, 50, 50));
        JButton defendButton = createButton("Defend", new Color(255, 165, 0));
        JButton usePotionButton = createButton("Use Potion", new Color(255, 182, 196));
        JButton runButton = createButton("Run", new Color(0, 0, 255));
        buttonPanel.add(attackButton);
        buttonPanel.add(defendButton);
        buttonPanel.add(usePotionButton);
        buttonPanel.add(runButton);

        frame.add(buttonPanel, BorderLayout.SOUTH);
        attackButton.addActionListener(event -> playerAction("attack"));
        defendButton.addActionListener(event -> playerAction("defend"));
        usePotionButton.addActionListener(event -> playerAction("usePotion"));
        runButton.addActionListener(event -> playerAction("run"));

        frame.add(topPanel, BorderLayout.NORTH);

        p1ImageLabel = new JLabel(loadCharacterIcon((p1.getName())));
        p2ImageLabel = new JLabel(loadCharacterIcon((p2.getName())));

        JPanel imagePanel = new JPanel(new GridLayout(2, 1, 0, 10));
        imagePanel.setBackground(new Color(45, 45, 50));
        imagePanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        imagePanel.add(p1ImageLabel);;
        imagePanel.add(p2ImageLabel);

        frame.add(imagePanel, BorderLayout.WEST);

        frame.setVisible(true);
        logArea.append("Let the battle begin!\n");
    }

    private JButton createButton(String text, Color color) {
        JButton createButton = new JButton(text);
        createButton.setBackground(color);
        createButton.setForeground(Color.WHITE);
        createButton.setFont(new Font("Times New Roman", Font.BOLD, 12));
        createButton.setFocusPainted(false);
        createButton.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(color.darker(), 2), BorderFactory.createEmptyBorder(5, 10, 5, 10)));
        return createButton;
    }

    private void playerAction(String action) {
        GameLogic current = p1Turn ? p1 : p2;
        GameLogic target = p1Turn ? p2 : p1;
        StringBuilder log = new StringBuilder();
        switch (action) {
            case "attack" -> current.attack(target, log);
            case "defend" -> current.defend(log);
            case "usePotion" -> current.usePotion(log);
            case "run" -> {
                if (current.runAway(log)) {
                    endGameMessage(current.getName() + " fled! Game over.");
                    return;
                }
            }
            default -> log.append(action + " is not a valid action!\n");
        }
        logArea.append(log.toString());
        updateHP();

        if (target.getHealth() <= 0) {
            endGameMessage(target.getName() + " was defeated! " + current.getName() + " wins!\n");
            return;
        }
        p1Turn = !p1Turn;
        updateTurnLabel();
        if (!p1Turn && vsAI) {
            Timer timer = new Timer(200, event -> {
                ((Timer) event.getSource()).stop();
                aiTurn();
            });
            timer.setRepeats(false);
            timer.start();
        }
    }

    private void aiTurn() {
        StringBuilder log = new StringBuilder();
        GameLogic ai = p2;
        GameLogic target = p1;
        int choice = decideAIAction();
        switch (choice) {
            case 0 -> ai.attack(target, log);
            case 1 -> ai.defend(log);
            case 2 -> ai.usePotion(log);
            case 3 -> {
                if (ai.runAway(log)) {
                    endGameMessage(ai.getName() + " fled!\n Game over! \nYOU WIN!");
                }
            }
            default -> ai.attack(target, log);
        }
        logArea.append(log.toString());
        updateHP();
        if (target.getHealth() <= 0) {
            endGameMessage(target.getName() + " was defeated! " + ai.getName() + " Wins\n");
            return;
        }
        p1Turn = true;
        updateTurnLabel();
    }

    private int decideAIAction() {
        double random = Math.random();
        switch (aiDifficulty) {
            case "Easy": if (random < 0.8) {
                return 0;
            } else if (random < 0.9) {
                return 1;
            } else {
                return 2;
            }
            case "Normal": {
                return (int)(Math.random() * 3);
            }
            case "Hard": {
                int health = p2.getHealth();
                if (health < 30 && random < 0.5) {
                    return 1;
                } else if (health < 50 && random < 0.5) {
                    return 2;
                } else {
                    return 0;
                }
            }
        }
        return 0;
    }

    private void updateHP() {
        p1Label.setText(p1.getName() + " HP " + Math.max(0,p1.getHealth()));
        p2Label.setText(p2.getName() + " HP " + Math.max(0,p2.getHealth()));
        p1HP.setValue(Math.max(0,p1.getHealth()));
        p2HP.setValue(Math.max(0,p2.getHealth()));
    }

    private void updateTurnLabel() {
        if (turnLabel != null) {
            turnLabel.setText("Turn: " + (p1Turn ? p1.getName() : p2.getName()));
        }
    }

    private void endGameMessage(String message) {
        logArea.append("\n" + message + "\n");

        GameLogic winner = (p1.getHealth() > 0)? p1 : p2;
        ImageIcon winnerIcon = loadCharacterIcon(winner.getName());

        JOptionPane.showMessageDialog(frame, message, "Battle Result", JOptionPane.PLAIN_MESSAGE, winnerIcon);
        frame.setEnabled(false);
    }
    public static void main(String[] args) {
        new GameMenu(((vsAI, aiDifficulty, p1Character, p2Character) -> new GameGUI(vsAI, aiDifficulty, p1Character, p2Character)));
    }
}
