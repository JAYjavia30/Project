/***************************************************
 * CSCI 185 M01
 * Fall 2025
 *
 * Names: Jay Javia & Jesus Maldonado
 * Date: 12/10/2025
 */


public class GameLogic {
    private String name;
    private int maxHealth;
    private int health;
    private int attack;
    private int defense;
    private int numPotions = 3;
    private boolean isDefending;
    private boolean criticalHit;
    private static final String[] characterList = {"Knight", "Zombie", "Mage", "Skeleton"};

    public GameLogic(String name, int hp, int attack, int defense) {
        this.name = name;
        this.maxHealth = hp;
        this.health = hp;
        this.attack = attack;
        this.defense = defense;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMaxHealth() {
        return maxHealth;
    }

    public void setMaxHealth(int maxHealth) {
        this.maxHealth = maxHealth;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = Math.max(0, Math.min(health, maxHealth));
    }

    public int getAttack() {
        return attack;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public int getDefense() {
        return defense;
    }

    public void setDefense(int defense) {
        this.defense = defense;
    }

    public int getNumPotions() {
        return numPotions;
    }

    public void setNumPotions(int numPotions) {
        this.numPotions = numPotions;
    }

    public boolean isDefending() {
        return isDefending;
    }

    public void setDefending(boolean defending) {
        isDefending = defending;
    }

    public boolean isCriticalHit() {
        return criticalHit;
    }

    public static String[] getCharacterList() {
        return characterList;
    }

    public int calculateDamage(StringBuilder log) {
        criticalHit = false;
        int baseAttack = (int)(Math.random() * 6) + 1;
        int totalDamage = baseAttack + attack;
        if (Math.random() < 0.1) {
            totalDamage *= 2;
            criticalHit = true;
        }
        return totalDamage;
    }

    public void attack(GameLogic target, StringBuilder log) {
        isDefending = false;
        log.append(name + " prepares to attack!\n");
        int damage = calculateDamage(log);
        if (criticalHit) {
            log.append(name + " landed a critical hit!\n");
        }
        if (target.isDefending) {
            log.append(target.name + " is defending and reduced the damage by " + target.defense + "!\n");
            damage -= target.defense;
            if (damage < 0) {
                damage = 0;
            }
        }
        int targetHealthBefore = target.health;
        int targetHealthAfter = targetHealthBefore - damage;
        target.health = targetHealthAfter;
        log.append(name + " dealt " + damage + " damage" + " to " + target.name + "\n");
        log.append(target.name + "'s health went from " + targetHealthBefore + " HP to " + targetHealthAfter + "\n");
    }

    public void defend(StringBuilder log) {
        isDefending = true;
        log.append(name + " prepares to block!\n");
    }

    public void usePotion(StringBuilder log) {
        isDefending = false;
        if (numPotions <= 0) {
            log.append(name + " has no potions left!\n");
            return;
        }
        int amountHealed = (int) (Math.random() * 50) + 1;
        if (health + amountHealed > maxHealth) {
            amountHealed = maxHealth - health;
        }
        health += amountHealed;
        numPotions--;
        log.append(name + " used a potion and healed " + amountHealed + " HP!\n");
    }

    public boolean runAway(StringBuilder log) {
        int chance = (int) (Math.random() * 100) + 1;
        if (chance > 25) {
            log.append(name + " tried fleeing from the battle and...\n");
            log.append(name + " successfully fled from the battle!\n");
            return true;
        } else {
            log.append(name + " tried fleeing from the battle and...\n");
            log.append(name + " failed to flee from the battle!\n");
            return false;
        }
    }
}

