/***************************************************
 * CSCI 185 M01
 * Fall 2025
 *
 * Names: Jay Javia & Jesus Maldonado
 * Date: 12/10/2025
 */
import javax.swing.*;
import java.awt.*;

public class GameMenu extends JFrame {
    public interface MenuListener {
        void startGame(boolean vsAI, String aiDifficulty, String p1Character, String p2Character);
    }

    public GameMenu(MenuListener listener) {
        super("RPG Battle - Menu");
        setSize(450, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new GridLayout(8,2,10,10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15,15,15,15));
        add(mainPanel);

        JLabel p1Label = new JLabel("Player 1: ");
        p1Label.setHorizontalAlignment(SwingConstants.RIGHT);

        JLabel p2Label = new JLabel("Player 2: ");
        p2Label.setHorizontalAlignment(SwingConstants.RIGHT);

        String[] characters = {"Knight", "Zombie", "Mage", "Skeleton"};
        JComboBox<String> p1ComboBox = new JComboBox<>(characters);
        JComboBox<String> p2ComboBox = new JComboBox<>(characters);

        JLabel modeLabel = new JLabel( "Game Mode:");
        modeLabel.setHorizontalAlignment(SwingConstants.RIGHT);

        JRadioButton aiButton = new JRadioButton("Player vs AI");
        JRadioButton pvpButton = new JRadioButton("Player 1 vs Player 2");
        ButtonGroup modeGroup = new ButtonGroup();
        modeGroup.add(aiButton);
        modeGroup.add(pvpButton);

        JLabel difficultyLabel = new JLabel("AI Difficulty: ");
        difficultyLabel.setHorizontalAlignment(SwingConstants.RIGHT);

        String[] difficulties = {"Easy", "Normal", "Hard"};
        JComboBox<String> difficultyComboBox = new JComboBox<>(difficulties);
        difficultyComboBox.setEnabled(false);

        aiButton.addActionListener(e -> {
            difficultyComboBox.setEnabled(true);
            p2ComboBox.setEnabled(false);
        });

        pvpButton.addActionListener(e -> {
            difficultyComboBox.setEnabled(false);
            p2ComboBox.setEnabled(true);
        });

        JButton startButton = new JButton("Start Game");

        mainPanel.add(p1Label);
        mainPanel.add(p1ComboBox);
        mainPanel.add(p2Label);
        mainPanel.add(p2ComboBox);
        mainPanel.add(modeLabel);
        mainPanel.add(new JLabel(""));
        mainPanel.add(aiButton);
        mainPanel.add(pvpButton);
        mainPanel.add(difficultyLabel);
        mainPanel.add(difficultyComboBox);
        mainPanel.add(new JLabel(""));
        mainPanel.add(startButton);
        setVisible(true);

        startButton.addActionListener(e -> {
            boolean vsAI = aiButton.isSelected();
            if (!vsAI && !pvpButton.isSelected()) {
                JOptionPane.showMessageDialog(this, "Please Select a Game Mode.");
                return;
            }
            String aiDifficulty = vsAI ? (String)difficultyComboBox.getSelectedItem() : null;
            listener.startGame(vsAI, aiDifficulty, (String)p1ComboBox.getSelectedItem(), (String)p2ComboBox.getSelectedItem());
            dispose();
        });
    }
}








